package com.example.alumni;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.util.List;

public class Supportadapter extends FirebaseRecyclerAdapter<Suppots,Supportadapter.MyViewholder> {
    private List<Suppots> suppotsList;


    public Supportadapter(@NonNull FirebaseRecyclerOptions<Suppots> options) {
        super(options);
    }


    @Override
    protected void onBindViewHolder(@NonNull Supportadapter.MyViewholder holder, int position, @NonNull Suppots model) {

        holder.srn.setText(model.getSrn());
        holder.transactio_id.setText(model.getTransactionId());
        holder.branch.setText(model.getBranch());
        holder.year_of_graduation.setText(model.getYearofgraduation());
        holder.required_documents.setText(model.getDocument());

    }

    @NonNull
    @Override
    public Supportadapter.MyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.support_layout,parent,false);
        return new MyViewholder(view);
    }

    class MyViewholder extends RecyclerView.ViewHolder{
        private TextView srn,transactio_id,year_of_graduation,branch,required_documents;

        public MyViewholder(@NonNull View itemView) {
            super(itemView);
            srn=(TextView)itemView.findViewById(R.id.srn2);
            transactio_id=(TextView)itemView.findViewById(R.id.trans_id);
            branch=(TextView)itemView.findViewById(R.id.specification_branch2);
            year_of_graduation=(TextView)itemView.findViewById(R.id.year_of_graduation2);
            required_documents=(TextView)itemView.findViewById(R.id.required_documents2);

        }
    }
}
