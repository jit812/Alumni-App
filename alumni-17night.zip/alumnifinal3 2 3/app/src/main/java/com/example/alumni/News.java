package com.example.alumni;

public class News {
    private String news,imageUrl;


    public News()
    {

    }

    public News(String news,String imageUrl)
    {
        this.news = news;
        this.imageUrl=imageUrl;
    }

    public String getNews() {
        return news;
    }

    public void setNews(String news) {
        this.news = news;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
