package com.reva.reva_mobile_app.ui.MarksDetails;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.reva.reva_mobile_app.R;

public class MarksDetailsFragment extends Fragment {

    private MarksDetailsViewModel marksDetailsViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        marksDetailsViewModel =
                new ViewModelProvider(this).get(MarksDetailsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_marks_details, container, false);
        final TextView textView = root.findViewById(R.id.text_marksdetails);
        marksDetailsViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;
    }
}