package com.reva.reva_mobile_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

public class SplashScreen extends AppCompatActivity {

    String id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        String SP="sharedPrefs";
        SharedPreferences sharedPreferences=getSharedPreferences(SP,MODE_PRIVATE);
         id=sharedPreferences.getString("id","empty");

        new Handler().postDelayed(new Runnable(){
            @Override
            public void run() {

                /* Create an Intent that will start the Menu-Activity. */

                if(!id.equals("empty"))
                {
                    Intent mainIntent = new Intent(SplashScreen.this, MainActivity.class);
                    mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                    SplashScreen.this.startActivity(mainIntent);
                    SplashScreen.this.finish();
                }

                else
                {
                    Intent mainIntent = new Intent(SplashScreen.this, LoginActivity.class);
                    mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                    SplashScreen.this.startActivity(mainIntent);
                    SplashScreen.this.finish();
                }


            }
        }, 1000);
    }
}