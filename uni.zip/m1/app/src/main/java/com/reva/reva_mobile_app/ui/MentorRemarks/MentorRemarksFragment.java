package com.reva.reva_mobile_app.ui.MentorRemarks;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.reva.reva_mobile_app.R;

public class MentorRemarksFragment extends Fragment {

    private MentorRemarksViewModel mentorRemarksViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        mentorRemarksViewModel =
                new ViewModelProvider(this).get(MentorRemarksViewModel.class);
        View root = inflater.inflate(R.layout.fragment_mentor_remarks, container, false);
        final TextView textView = root.findViewById(R.id.text_mentorremarks);
        mentorRemarksViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;
    }
}