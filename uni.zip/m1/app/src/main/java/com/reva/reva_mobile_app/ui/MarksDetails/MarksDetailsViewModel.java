package com.reva.reva_mobile_app.ui.MarksDetails;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MarksDetailsViewModel extends ViewModel {
    // TODO: Implement the ViewModel

    private MutableLiveData<String> mText;

    public MarksDetailsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is marks details fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}