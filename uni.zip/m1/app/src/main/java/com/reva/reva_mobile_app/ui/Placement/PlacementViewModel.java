package com.reva.reva_mobile_app.ui.Placement;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class PlacementViewModel extends ViewModel {
    // TODO: Implement the ViewModel

    private MutableLiveData<String> mText;

    public PlacementViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is Placement fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}