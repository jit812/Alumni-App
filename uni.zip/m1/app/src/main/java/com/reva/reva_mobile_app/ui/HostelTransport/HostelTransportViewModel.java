package com.reva.reva_mobile_app.ui.HostelTransport;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HostelTransportViewModel extends ViewModel {
    // TODO: Implement the ViewModel
    private MutableLiveData<String> mText;

    public HostelTransportViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is Hostel Transport fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}