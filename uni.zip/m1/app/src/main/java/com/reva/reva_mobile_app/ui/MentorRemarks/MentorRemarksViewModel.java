package com.reva.reva_mobile_app.ui.MentorRemarks;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MentorRemarksViewModel extends ViewModel {
    // TODO: Implement the ViewModel

    private MutableLiveData<String> mText;

    public MentorRemarksViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is Mentor remarks fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}