package com.reva.reva_mobile_app.ui.ExamDetails;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class ExamDetailsViewModel extends ViewModel {
    // TODO: Implement the ViewModel

    private MutableLiveData<String> mText;

    public ExamDetailsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is Exam details fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }

}
