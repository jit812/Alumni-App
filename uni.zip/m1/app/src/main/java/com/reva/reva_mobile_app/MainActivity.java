package com.reva.reva_mobile_app;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.microsoft.identity.client.AuthenticationCallback;
import com.microsoft.identity.client.IAccount;
import com.microsoft.identity.client.IAuthenticationResult;
import com.microsoft.identity.client.IPublicClientApplication;
import com.microsoft.identity.client.ISingleAccountPublicClientApplication;
import com.microsoft.identity.client.PublicClientApplication;
import com.microsoft.identity.client.SilentAuthenticationCallback;
import com.microsoft.identity.client.exception.MsalClientException;
import com.microsoft.identity.client.exception.MsalException;
import com.microsoft.identity.client.exception.MsalServiceException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.android.material.navigation.NavigationView;
import com.microsoft.identity.client.exception.MsalUiRequiredException;

public class MainActivity extends AppCompatActivity {


    private ISingleAccountPublicClientApplication mSingleAccountApp;
    private IAccount mAccount = null;

    DrawerLayout drawerLayout;
    ActionBarDrawerToggle toggle;
    Toolbar toolbar;
    NavigationView navigationView;
    Fragment fragment=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        drawerLayout=findViewById(R.id.drawer);
        toolbar=findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        toggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);

        drawerLayout.addDrawerListener(toggle);

        toggle.syncState();
        navigationView=findViewById(R.id.nav_vieww);
        fragment =new HomeFragment();
        loadFragment(fragment);
        PublicClientApplication.createSingleAccountPublicClientApplication(getApplicationContext(),
                R.raw.auth_config_single_account,
                new IPublicClientApplication.ISingleAccountApplicationCreatedListener() {
                    @Override
                    public void onCreated(ISingleAccountPublicClientApplication application) {
                        mSingleAccountApp = application;
                        loadAccount();
                    }

                    @Override
                    public void onError(MsalException exception) {

                    }


                });
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {


                int id=menuItem.getItemId();


                switch (id)

                {
                    case R.id.nav_homee:

                        fragment =new HomeFragment();
                        loadFragment(fragment);
                        break;

                    case R.id.nav_attendencee:

                        fragment =new AttendenceeFragment();
                        loadFragment(fragment);
                        break;

                    case R.id.nav_profilee:

                        fragment =new ProfileeFragment();
                        loadFragment(fragment);
                        break;

                    case R.id.nav_logout:

                        try {

                            mSingleAccountApp.signOut(new ISingleAccountPublicClientApplication.SignOutCallback() {
                                @Override
                                public void onSignOut() {


                                   if(mAccount != null)

                                   {
                                      mAccount = null;

                                       PreferenceManager.getDefaultSharedPreferences(getBaseContext()).edit().clear().apply();
                                       Intent mainIntent = new Intent(getApplicationContext(), LoginActivity.class);
                                       mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                                       startActivity(mainIntent);
                                   }
                                   else{
                                       PreferenceManager.getDefaultSharedPreferences(getBaseContext()).edit().clear().apply();
                                       Intent mainIntent = new Intent(getApplicationContext(), LoginActivity.class);
                                       mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                   }








                                }

                                @Override
                                public void onError(@NonNull MsalException exception) {
                                    Toast.makeText(getApplicationContext(),exception.getMessage(),Toast.LENGTH_LONG).show();


                                }
                            });
                        }

                        catch (Exception e)
                        {
                            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                        }


                        break;


                    default:
                        return  true;

                }
                return  true;


            }
        });





    }

    private SilentAuthenticationCallback getAuthSilentCallback() {
        return new SilentAuthenticationCallback() {

            @Override
            public void onSuccess(IAuthenticationResult authenticationResult) {

                /* Successfully got a token, use it to call a protected resource - MSGraph */
                callGraphAPI(authenticationResult);
            }

            @Override
            public void onError(MsalException exception) {
                /* Failed to acquireToken */
                displayError(exception);

                if (exception instanceof MsalClientException) {
                    /* Exception inside MSAL, more info inside MsalError.java */
                } else if (exception instanceof MsalServiceException) {
                    /* Exception when communicating with the STS, likely config issue */
                } else if (exception instanceof MsalUiRequiredException) {
                    /* Tokens expired or no session, retry with interactive */
                }
            }
        };
    }
    private void displayGraphResult(@NonNull final JSONObject graphResponse) {
    }

    private void displayError(@NonNull final Exception exception) {
    }


    private String[] getScopes() {
        String s[] = {"User.ReadWrite.All"};
        return s;
    }




    private void loadFragment(Fragment fragment) {

        FragmentManager fragmentManager=getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.framee,fragment).commit();
        drawerLayout.closeDrawer(GravityCompat.START);
        fragmentTransaction.addToBackStack(null);

    }
    private void loadAccount() {
        if (mSingleAccountApp == null) {
            return;
        }
        mSingleAccountApp.getCurrentAccountAsync(new ISingleAccountPublicClientApplication.CurrentAccountCallback() {
            @Override
            public void onAccountLoaded(@Nullable IAccount activeAccount) {
                // You can use the account data to update your UI or your app database.
                mAccount = activeAccount;
               // updateUI();
            }

            @Override
            public void onAccountChanged(@Nullable IAccount priorAccount, @Nullable IAccount currentAccount) {
                if (currentAccount == null) {
                    // Perform a cleanup task as the signed-in account changed.
                }
            }

            @Override
            public void onError(@NonNull MsalException exception) {
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mSingleAccountApp == null) {
            return;
        }

        /**
         * Once you've signed the user in,
         * you can perform acquireTokenSilent to obtain resources without interrupting the user.
         */
        mSingleAccountApp.acquireTokenSilentAsync(getScopes(), mAccount.getAuthority(), getAuthSilentCallback());
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (mSingleAccountApp == null) {
            return;
        }

        /**
         * Once you've signed the user in,
         * you can perform acquireTokenSilent to obtain resources without interrupting the user.
         */
        mSingleAccountApp.acquireTokenSilentAsync(getScopes(), mAccount.getAuthority(), getAuthSilentCallback());
    }
    private void callGraphAPI(final IAuthenticationResult authenticationResult) {
        MSGraphRequestWrapper.callGraphAPIUsingVolley(
                getApplicationContext(),
                "https://graph.microsoft.com/v1.0/me",
                authenticationResult.getAccessToken(),
                new Response.Listener<JSONObject>() {
                    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onResponse(JSONObject response) {
                        /* Successfully called graph, process data and send to UI */



                        displayGraphResult(response);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        displayError(error);
                    }
                });
    }



}
