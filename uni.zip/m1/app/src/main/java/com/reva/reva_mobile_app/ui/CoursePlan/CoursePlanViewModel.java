package com.reva.reva_mobile_app.ui.CoursePlan;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class CoursePlanViewModel extends ViewModel {


    private MutableLiveData<String> mText;

    public CoursePlanViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is course plan fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }

}