package com.reva.reva_mobile_app.ui.Attendence;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class AttendenceViewModel extends ViewModel {
    // TODO: Implement the ViewModel
    private MutableLiveData<String> mText;

    public AttendenceViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is Attendence fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}